import axios from 'axios';
import yts from 'yt-search';
import fetch from 'node-fetch';
import os from 'os';
import ffmpeg from 'fluent-ffmpeg';

let handler = async (m, { conn, text, usedPrefix, command }) => {

  if (!text) throw m.reply(`Ejemplo de uso: ${usedPrefix + command} Waguri Edit`);
  
    let results = await yts(text);
    let tes = results.videos[0]
    
  const args = text.split(' ');
  const videoUrl = args[0];
  const resolution = args[1] || '480';

  const apiUrl = `https://api.ryzendesu.vip/api/downloader/ytmp4?url=${encodeURIComponent(tes.url)}&reso=360`;

  try {
    const response = await axios.get(apiUrl);
    const { url: videoStreamUrl, filename } = response.data;

    if (!videoStreamUrl) throw m.reply('No se encontró la data para esta consulta, intenta usar otro titulo.');

    const tmpDir = os.tmpdir();
    const filePath = `${tmpDir}/${filename}`;

    const writer = fs.createWriteStream(filePath);
    const downloadResponse = await axios({
      url: videoStreamUrl,
      method: 'GET',
      responseType: 'stream'
    });

    downloadResponse.data.pipe(writer);

    await new Promise((resolve, reject) => {
      writer.on('finish', resolve);
      writer.on('error', reject);
    });

    const outputFilePath = `${tmpDir}/${filename.replace('.mp4', '_fixed.mp4')}`;

    await new Promise((resolve, reject) => {
      ffmpeg(filePath)
        .outputOptions('-c copy')
        .output(outputFilePath)
        .on('end', resolve)
        .on('error', reject)
        .run();
    });

    let ps = `Aqui tiene su video @${m.sender.split('@')[0]}\n\nNombre del archivo: ${filename}`;

    await conn.sendMessage(m.chat, {
      video: { url: outputFilePath },
      mimetype: "video/mp4",
      fileName: filename,
      caption: ps,
      mentions: [m.sender]
    }, { quoted: m });

    fs.unlink(filePath, (err) => {
      if (err) {
        console.error(`Failed to delete original video file: ${err}`);
      } else {
        console.log(`Deleted original video file: ${filePath}`);
      }
    });

    fs.unlink(outputFilePath, (err) => {
      if (err) {
        console.error(`Failed to delete processed video file: ${err}`);
      } else {
        console.log(`Deleted processed video file: ${outputFilePath}`);
      }
    });

  } catch (error) {
    console.error(`Error: ${error.message}`);
    throw m.reply(`Failed to process request: ${error.message || error}`);
  }
}
handler.help = ['playvideo'];
handler.tags = ['downloader'];
handler.command = /^(playvideo|playvid)$/i;

export default handler;